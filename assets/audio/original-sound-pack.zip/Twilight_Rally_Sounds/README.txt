TWILIGHT RALLY: ORIGINAL SOUND CONCEPT PACK

15 original synthesized sound effects. No external samples used.
All WAV files are mono, 22,050 Hz, 16-bit PCM.
This is a first-pass design pack for audition and iteration, not final mastering.
For production, consider transcoding selected effects to optimized formats and test browser support.

paddle_hit_soft.wav | Paddle hit, quiet | 0.09 sec | 3.9 KB
paddle_hit_strong.wav | Paddle hit, powerful | 0.13 sec | 5.6 KB
wall_bounce.wav | Ball contacts arena wall | 0.07 sec | 3.1 KB
point_won.wav | Player scores point | 0.48 sec | 20.7 KB
point_lost.wav | Opponent scores point | 0.31 sec | 13.2 KB
countdown_tick.wav | Every second in countdown | 0.1 sec | 4.3 KB
countdown_final.wav | Final GO cue after countdown | 0.16 sec | 6.9 KB
menu_select.wav | Button and menu selection | 0.06 sec | 2.8 KB
menu_back.wav | Return or close menu | 0.06 sec | 2.8 KB
pause.wav | Match paused | 0.23 sec | 9.7 KB
player_joined.wav | Friend joins private room | 0.28 sec | 12.1 KB
achievement.wav | Achievement unlocked | 0.51 sec | 22.0 KB
level_complete.wav | Solo level complete | 0.79 sec | 34.1 KB
match_victory.wav | Match victory short fanfare | 1.19 sec | 51.3 KB
error_soft.wav | Non-disruptive error or unavailable action | 0.13 sec | 5.6 KB

Playback guidance: use normal gain around 0.4-0.7; put a limiter on the output; vary paddle-hit pitch subtly; avoid stacking duplicate sounds on overlapping events; mute/unmute and reduced-sensory options. Browsers generally require user interaction before audio playback.
